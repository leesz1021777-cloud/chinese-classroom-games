@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo 请先安装 Node.js 24 LTS。安装后可完全离线运行。
  pause
  exit /b 1
)
node serve.mjs --open
pause
